# Beingfixed Landing Page

A modern, responsive landing page for Beingfixed - an apartment maintenance platform that connects landlords, tenants, and property managers.

## Features

- **Modern Design**: Clean, professional design with rounded cards and clear CTAs
- **Email Capture**: Three strategic email capture sections with Supabase integration
- **Responsive**: Mobile-first design that works on all devices
- **Real-time Database**: Waitlist emails stored in Supabase with duplicate prevention
- **Form Validation**: Client and server-side email validation
- **Loading States**: Proper loading and error handling for form submissions
- **SEO Optimized**: Meta tags and structured data for search engines

## Tech Stack

- **Next.js 15** - React framework for production
- **TypeScript** - Type safety
- **Tailwind CSS v4** - Utility-first CSS framework
- **Supabase** - Backend as a service for database
- **Motion** - Animation library
- **Lucide React** - Beautiful icons

## Prerequisites

Before you begin, ensure you have:

- Node.js 18.x or later
- npm or yarn package manager
- A Supabase account and project

## Getting Started

### 1. Clone the repository

```bash
git clone https://github.com/yourusername/beingfixed-landing.git
cd beingfixed-landing
```

### 2. Install dependencies

```bash
npm install
# or
yarn install
```

### 3. Set up environment variables

Create a `.env.local` file in the root directory:

```bash
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

You can find these values in your Supabase project dashboard under Settings > API.

### 4. Set up Supabase database

Create a table called `waitlist` in your Supabase project:

```sql
CREATE TABLE waitlist (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email VARCHAR NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Enable Row Level Security
ALTER TABLE waitlist ENABLE ROW LEVEL SECURITY;

-- Create policy for inserting emails
CREATE POLICY "Allow public email inserts" ON waitlist
  FOR INSERT TO anon
  WITH CHECK (true);
```

### 5. Run the development server

```bash
npm run dev
# or
yarn dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser to see the application.

## Project Structure

```
beingfixed-landing/
├── app/
│   ├── api/
│   │   └── waitlist/
│   │       └── route.ts          # API endpoint for email submissions
│   ├── layout.tsx                # Root layout with metadata
│   └── page.tsx                  # Main landing page
├── components/
│   ├── figma/
│   │   └── ImageWithFallback.tsx # Image component with fallback
│   ├── ui/                       # Shadcn/ui components
│   └── EmailCapture.tsx          # Reusable email capture component
├── hooks/
│   └── useWaitlist.ts            # Custom hook for email submission
├── lib/
│   └── supabase.ts               # Supabase client configuration
├── styles/
│   └── globals.css               # Global styles and Tailwind config
├── next.config.js                # Next.js configuration
├── package.json                  # Dependencies and scripts
├── tsconfig.json                 # TypeScript configuration
└── README.md                     # Project documentation
```

## API Endpoints

### POST /api/waitlist

Submit an email to join the waitlist.

**Request Body:**
```json
{
  "email": "user@example.com"
}
```

**Responses:**
- `201`: Email successfully added to waitlist
- `400`: Invalid email format or missing email
- `409`: Email already exists in waitlist
- `500`: Server error

## Deployment

### Deploy to Vercel (Recommended)

1. **Connect to Vercel:**
   - Go to [vercel.com](https://vercel.com)
   - Import your GitHub repository
   - Vercel will automatically detect Next.js

2. **Set environment variables:**
   - In your Vercel dashboard, go to Settings > Environment Variables
   - Add your Supabase credentials:
     - `NEXT_PUBLIC_SUPABASE_URL`
     - `NEXT_PUBLIC_SUPABASE_ANON_KEY`

3. **Deploy:**
   - Vercel will automatically deploy on every push to main branch
   - Your site will be available at `https://your-project.vercel.app`

### Deploy to Netlify

1. **Build settings:**
   - Build command: `npm run build`
   - Publish directory: `.next`

2. **Environment variables:**
   - Add your Supabase credentials in Netlify dashboard

### Other Deployment Options

The app can be deployed to any platform that supports Next.js:
- AWS Amplify
- Heroku
- DigitalOcean App Platform
- Railway

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `NEXT_PUBLIC_SUPABASE_URL` | Your Supabase project URL | Yes |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Your Supabase anonymous key | Yes |

## Customization

### Changing Colors

The design uses custom colors defined in `globals.css`. Key colors:

- Primary blue: `#005eff` (buttons, accents)
- Success green: `#16a34a` (success states)
- Background blue: `rgba(237,246,255,1)` (section backgrounds)

### Adding New Sections

1. Create a new section in `app/page.tsx`
2. Follow the existing pattern with proper spacing (`py-20`)
3. Use the container pattern: `container mx-auto px-6 max-w-6xl`

### Email Capture Customization

The `EmailCapture` component accepts these props:

- `buttonText`: Custom button text
- `buttonColor`: 'blue' | 'green' | 'primary'
- `placeholder`: Input placeholder text
- `successMessage`: Custom success message
- `className`: Additional CSS classes

## Analytics

To add analytics, install your preferred solution:

```bash
npm install @vercel/analytics
# or
npm install gtag
```

Then add to `app/layout.tsx`.

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

If you need help with deployment or customization, please:

1. Check the documentation above
2. Search existing GitHub issues
3. Create a new issue with detailed information

## Performance

The site is optimized for performance:

- Static generation where possible
- Optimized images with next/image
- Minimal JavaScript bundle
- Fast loading animations

Lighthouse scores should be 90+ across all categories.