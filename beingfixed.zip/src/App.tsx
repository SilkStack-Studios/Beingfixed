import image_8f333281b8c861bd8cb7bcf1a12be1a876de0f11 from 'figma:asset/8f333281b8c861bd8cb7bcf1a12be1a876de0f11.png';
import { Button } from './components/ui/button';
import { Card } from './components/ui/card';
import { Input } from './components/ui/input';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { motion } from 'motion/react';
import { 
  Clock,
  X,
  AlertTriangle,
  FileText,
  ArrowRight,
  CheckCircle,
  Camera,
  Bell,
  BarChart3,
  MessageCircle,
  Home,
  Users,
  Building,
  Wrench,
  Check,
  TrendingUp,
  Shield,
  Mail
} from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Logo Header */}
      <header className="bg-white py-6">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-sm">B</span>
            </div>
            <span className="font-semibold text-gray-900">Beingfixed</span>
          </div>
        </div>
      </header>

      {/* Hero Email Capture Section */}
      <section className="bg-[rgba(237,246,255,1)] py-20">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <div className="space-y-6">
                <h1 className="text-5xl leading-tight text-gray-900">
                  Be the First to Fix Apartment Issues <span className="text-blue-600">Faster</span>
                </h1>
                <p className="text-lg text-gray-600 leading-relaxed">
                  Join the Beingfixed waitlist today and get early access to hassle-free apartment maintenance.
                </p>
              </div>
              
              {/* Email Capture Form */}
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row gap-3 max-w-md">
                  <Input 
                    type="email" 
                    placeholder="you@example.com"
                    className="bg-white text-gray-900 border-gray-300 rounded-lg flex-1"
                  />
                  <Button 
                    className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg transition-all duration-300 hover:scale-105"
                  >
                    Join the Waitlist
                  </Button>
                </div>
                <p className="text-sm text-gray-500">
                  No spam. You can unsubscribe anytime.
                </p>
              </div>

              {/* Social Proof */}
              <div className="bg-white rounded-lg p-4 border border-gray-200 max-w-md">
                <p className="text-sm text-gray-700">
                  <span className="font-semibold text-green-600">50+ landlords and tenants</span> already signed up!
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-6 pt-4">
                <div className="flex items-center space-x-3">
                  <Check className="h-4 w-4 text-green-600" />
                  <span className="text-sm text-gray-600">Free for first 100 users</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Check className="h-4 w-4 text-green-600" />
                  <span className="text-sm text-gray-600">No credit card required</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <motion.div 
                className="bg-white rounded-xl p-6 shadow-lg transform rotate-3"
                whileHover={{ 
                  rotate: -2, 
                  scale: 1.05,
                  transition: { duration: 0.3, ease: "easeOut" }
                }}
                initial={{ rotate: 3 }}
                animate={{ rotate: 3 }}
              >
                <ImageWithFallback 
                  src={image_8f333281b8c861bd8cb7bcf1a12be1a876de0f11}
                  alt="Modern apartment building exterior"
                  className="w-full h-80 object-cover rounded-lg"
                />
                <div className="mt-4 flex items-center space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  <span className="text-sm text-gray-600">Maintenance request submitted...</span>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-20 bg-[rgba(237,246,255,1)]">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="text-center space-y-12">
            <div className="space-y-4">
              <h2 className="text-3xl text-gray-900">
                Current apartment maintenance is <span className="text-red-500">broken</span>
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Property managers, landlords, and tenants are all struggling with outdated systems that create more problems than they solve.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center space-y-4">
                <div className="bg-red-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <Clock className="h-8 w-8 text-red-500" />
                </div>
                <h3 className="font-semibold text-gray-900">Slow Communication</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Maintenance requests get lost in email chains and phone calls, leading to delayed responses and frustrated tenants.
                </p>
              </div>
              <div className="text-center space-y-4">
                <div className="bg-red-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <X className="h-8 w-8 text-red-500" />
                </div>
                <h3 className="font-semibold text-gray-900">Lost Requests</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Paper forms and scattered digital messages mean important maintenance issues fall through the cracks.
                </p>
              </div>
              <div className="text-center space-y-4">
                <div className="bg-red-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <AlertTriangle className="h-8 w-8 text-red-500" />
                </div>
                <h3 className="font-semibold text-gray-900">Frustrated Tenants</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Lack of transparency and poor communication creates tension between tenants and property management.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section className="py-20 bg-[rgba(237,246,255,1)]">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="text-center space-y-12">
            <div className="space-y-4">
              <h2 className="text-3xl text-gray-900">
                Simple as <span className="text-blue-600">1-2-3</span>
              </h2>
              <p className="text-lg text-gray-600">
                Beingfixed streamlines the entire maintenance process, making it effortless for everyone involved.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <Card className="p-8 text-center space-y-4 bg-white border-0 shadow-sm">
                <div className="bg-red-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <FileText className="h-8 w-8 text-red-500" />
                </div>
                <h3 className="font-semibold text-gray-900">Report</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Tenants easily submit maintenance requests with photos and descriptions through the app.
                </p>
              </Card>
              <Card className="p-8 text-center space-y-4 bg-white border-0 shadow-sm">
                <div className="bg-yellow-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <ArrowRight className="h-8 w-8 text-yellow-600" />
                </div>
                <h3 className="font-semibold text-gray-900">Route</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Requests are automatically routed to the right person with all the context they need.
                </p>
              </Card>
              <Card className="p-8 text-center space-y-4 bg-white border-0 shadow-sm">
                <div className="bg-green-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <CheckCircle className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-900">Resolve</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Track progress in real-time and get notifications when issues are completed.
                </p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-[rgba(237,246,255,1)]">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="text-center space-y-12">
            <div className="space-y-4">
              <h2 className="text-3xl text-gray-900">Everything you need</h2>
              <p className="text-lg text-gray-600">
                Simple tools that make apartment maintenance fast, transparent, and stress-free.
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center space-y-4">
                <div className="bg-blue-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <Camera className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="font-semibold text-gray-900">Photo & Video Uploads</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Capture the issue with photos and videos to ensure faster, more accurate repairs.
                </p>
              </div>
              <div className="text-center space-y-4">
                <div className="bg-blue-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <Bell className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="font-semibold text-gray-900">Real-time Updates</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Get instant notifications when your request is received, assigned, and completed.
                </p>
              </div>
              <div className="text-center space-y-4">
                <div className="bg-blue-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <BarChart3 className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="font-semibold text-gray-900">Management Dashboard</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Track all requests, monitor response times, and keep your properties running smoothly.
                </p>
              </div>
              <div className="text-center space-y-4">
                <div className="bg-blue-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <MessageCircle className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="font-semibold text-gray-900">Vendor Chat</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Direct communication between tenants, managers, and repair professionals.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mid-page Email Capture Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6 max-w-4xl">
          <div className="text-center space-y-8">
            <div className="space-y-4">
              <h2 className="text-3xl text-gray-900">
                Be the First to Fix Apartment Issues <span className="text-blue-600">Faster</span>
              </h2>
              <p className="text-lg text-gray-600">
                Join the Beingfixed waitlist today and get early access to hassle-free apartment maintenance.
              </p>
            </div>
            
            {/* Email Capture Form */}
            <div className="max-w-md mx-auto space-y-4">
              <div className="flex flex-col sm:flex-row gap-3">
                <Input 
                  type="email" 
                  placeholder="you@example.com"
                  className="bg-white text-gray-900 border-gray-300 rounded-lg flex-1"
                />
                <Button 
                  className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-lg transition-all duration-300 hover:scale-105"
                >
                  Join the Waitlist
                </Button>
              </div>
              <p className="text-sm text-gray-500">
                Sign up now to secure your early access spot.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Who It's For Section */}
      <section className="py-20 bg-[rgba(237,246,255,1)]">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="text-center space-y-12">
            <div className="space-y-4">
              <h2 className="text-3xl text-gray-900 text-[36px] font-bold font-normal">Who it's for</h2>
              <p className="text-lg text-gray-600 text-[16px]">
                Beingfixed works for everyone in the apartment maintenance ecosystem.
              </p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center space-y-4">
                <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <Home className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-900">Landlords</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Keep tenants happy and properties well-maintained with clear communication and fast fixes.
                </p>
              </div>
              <div className="text-center space-y-4">
                <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <Users className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-900">Tenants</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Report issues easily and track progress with real-time updates and photo uploads.
                </p>
              </div>
              <div className="text-center space-y-4">
                <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <Building className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-900">Property Managers</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Manage multiple properties efficiently with centralized dashboards and automated workflows.
                </p>
              </div>
              <div className="text-center space-y-4">
                <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto">
                  <Wrench className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-900">Vendors</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Get clear job details, communicate directly, and build stronger client relationships.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-[rgba(237,246,255,1)]">
        <div className="container mx-auto px-6 max-w-6xl">
          <div className="text-center space-y-12">
            <div className="space-y-4">
              <h2 className="text-3xl text-gray-900">
                <span className="text-green-600">Fair pricing</span> that grows with you
              </h2>
              <p className="text-lg text-gray-600">
                We're building a sustainable platform that creates value for everyone in the maintenance ecosystem.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <Card className="p-8 space-y-6 bg-[rgba(255,255,255,1)] border-0">
                <div className="text-center">
                  <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <Check className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900">Monthly Subscription for Managers</h3>
                </div>
                <p className="text-gray-600 text-sm text-center leading-relaxed">
                  Simple per-property pricing that scales with your portfolio
                </p>
              </Card>
              <Card className="p-8 space-y-6 bg-[rgba(255,255,255,1)] border-0">
                <div className="text-center">
                  <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900">Premium Analytics</h3>
                </div>
                <p className="text-gray-600 text-sm text-center leading-relaxed">
                  Advanced insights and reporting for data-driven maintenance decisions
                </p>
              </Card>
              <Card className="p-8 space-y-6 bg-[rgba(255,255,255,1)] border-0">
                <div className="text-center">
                  <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <Shield className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900">Vendor Marketplace</h3>
                </div>
                <p className="text-gray-600 text-sm text-center leading-relaxed">
                  Connect with pre-vetted contractors and service providers in your area
                </p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20 bg-[rgba(0,0,0,1)]">
        <div className="container mx-auto px-6 max-w-4xl text-center">
          <div className="space-y-8">
            <h2 className="text-3xl lg:text-4xl text-white">
              Be the First to Fix Apartment Issues <span className="text-blue-400">Faster</span>
            </h2>
            <p className="text-lg text-gray-300">
              Join the Beingfixed waitlist today and get early access to hassle-free apartment maintenance.
            </p>
            <div className="max-w-md mx-auto">
              <div className="flex flex-col sm:flex-row gap-3">
                <Input 
                  type="email" 
                  placeholder="you@example.com"
                  className="bg-white text-gray-900 border-0 rounded-lg flex-1"
                />
                <Button className="bg-[rgba(0,94,255,1)] text-[rgba(255,255,255,1)] hover:bg-blue-700 rounded-lg px-6 transition-all duration-300 hover:scale-105">
                  <Mail className="h-4 w-4 mr-2" />
                  Join Waitlist
                </Button>
              </div>
              <p className="text-sm text-blue-100 mt-3">
                No spam. Unsubscribe anytime.
              </p>
              
              {/* Social Proof */}
              <div className="bg-gray-900 rounded-lg p-4 border border-gray-700 mt-6">
                <p className="text-sm text-gray-300">
                  <span className="font-semibold text-green-400">50+ landlords and tenants</span> already signed up!
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}