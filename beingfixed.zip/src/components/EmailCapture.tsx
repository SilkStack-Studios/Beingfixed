'use client'

import { useState } from 'react'
import { Button } from './ui/button'
import { Input } from './ui/input'
import { Mail, Check, AlertCircle } from 'lucide-react'
import { useWaitlist } from '@/hooks/useWaitlist'

interface EmailCaptureProps {
  buttonText?: string
  buttonColor?: 'blue' | 'green' | 'primary'
  placeholder?: string
  successMessage?: string
  className?: string
}

export function EmailCapture({
  buttonText = 'Join Waitlist',
  buttonColor = 'blue',
  placeholder = 'you@example.com',
  successMessage = 'Thanks! You\'re on the waitlist.',
  className = ''
}: EmailCaptureProps) {
  const [email, setEmail] = useState('')
  const { isLoading, error, success, submitEmail, reset } = useWaitlist()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (email) {
      await submitEmail(email)
    }
  }

  const getButtonClasses = () => {
    const baseClasses = 'px-8 py-3 rounded-lg transition-all duration-300 hover:scale-105'
    switch (buttonColor) {
      case 'green':
        return `${baseClasses} bg-green-600 hover:bg-green-700 text-white`
      case 'primary':
        return `${baseClasses} bg-[rgba(0,94,255,1)] text-[rgba(255,255,255,1)] hover:bg-blue-700`
      default:
        return `${baseClasses} bg-blue-600 hover:bg-blue-700 text-white`
    }
  }

  if (success) {
    return (
      <div className={`space-y-4 ${className}`}>
        <div className="flex items-center space-x-3 text-green-600">
          <Check className="h-5 w-5" />
          <span>{successMessage}</span>
        </div>
        <button
          onClick={() => {
            setEmail('')
            reset()
          }}
          className="text-sm text-gray-500 hover:text-gray-700 underline"
        >
          Submit another email
        </button>
      </div>
    )
  }

  return (
    <div className={`space-y-4 ${className}`}>
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
        <Input
          type="email"
          placeholder={placeholder}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          disabled={isLoading}
          className="bg-white text-gray-900 border-gray-300 rounded-lg flex-1"
        />
        <Button
          type="submit"
          disabled={isLoading || !email}
          className={getButtonClasses()}
        >
          {buttonColor === 'primary' && <Mail className="h-4 w-4 mr-2" />}
          {isLoading ? 'Joining...' : buttonText}
        </Button>
      </form>
      
      {error && (
        <div className="flex items-center space-x-2 text-red-600">
          <AlertCircle className="h-4 w-4" />
          <span className="text-sm">{error}</span>
        </div>
      )}
    </div>
  )
}