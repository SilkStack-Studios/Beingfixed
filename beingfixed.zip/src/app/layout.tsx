import type { Metadata } from 'next'
import '@/styles/globals.css'

export const metadata: Metadata = {
  title: 'Beingfixed - Fix Apartment Issues Faster',
  description: 'Join the Beingfixed waitlist and get early access to hassle-free apartment maintenance. Simple tools for landlords, tenants, and property managers.',
  keywords: 'apartment maintenance, property management, landlord, tenant, maintenance requests',
  authors: [{ name: 'Beingfixed' }],
  openGraph: {
    title: 'Beingfixed - Fix Apartment Issues Faster',
    description: 'Join the Beingfixed waitlist and get early access to hassle-free apartment maintenance.',
    url: 'https://beingfixed.com',
    siteName: 'Beingfixed',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Beingfixed - Fix Apartment Issues Faster',
    description: 'Join the Beingfixed waitlist and get early access to hassle-free apartment maintenance.',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}